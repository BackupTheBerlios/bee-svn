/**
 *   \brief    The side that runs the scripts.
 *   \see      axigenhost.c 
 *   \author   Cristina Balan, Andrei Paduraru, Marius Negreanu
 *   \date     Thu Aug 17 17:38:13 2006
 *
 *   Copyright (c) Gecad Technologies
 **/
#include <libgen.h>

#include "util.h"
#include "testbot.h"
#include "rshdaemon.h"
#include "socket.h"



struct globals_s glob;          /* used to pass parameters around */
int recursiveFlag = 1;
int forceFlag = TRUE;

int
main(int argc, char *argv[])
{
    extern char *optarg;
    extern int optind, optopt;

    printf("TestBot version %s\n", VER);
    tb_globalsInit(argc, argv);
    if (argc == 1) tb_usage();
    tb_parseArgs( argc, argv );

    if( glob.act_as_daemon ) {
        if( glob.port == 0 ) {
            fprintf(stderr, "You have to specify -p option\n");
            exit(-2);
        }
        rshDaemon(glob.port) ;
        return 0 ; 
    }

    tb_parseConf();
    tb_envInit();
    tb_checkTools(getenv(AXI_TOOL)) ;

    if (!glob.test_dir) {
        printf("* testbot: Provide the test directory.\n");
        tb_usage();
    }

    if (glob.test_type == TEST_LOCAL) {
        if (glob.verbose == TRUE)
            printf("* testbot: Tests will be done LOCALLY.\n");
    }
    if (glob.test_type == TEST_REMOTE) {
        util_isEnv(AXI_HOST);
        util_isEnv(AXI_PORT);
        if (glob.verbose == TRUE)
            printf("* testbot: Tests will be done REMOTE.\n");
    }
    tb_runTests(glob.test_dir);
    return 0;
}


static int
tb_parseArgs( int argc, char* argv[] )
{
    int c;
    while ((c = getopt(argc, argv, "Dt:h:p:d:o:r:v")) != -1)
    {
        switch (c)
        {
        case 't':
            if (!strcasecmp(optarg, "remote"))
                glob.test_type = TEST_REMOTE;
            if (!strcasecmp(optarg, "local"))
                glob.test_type = TEST_LOCAL;
            if (!glob.test_type) {
                printf("* testbot: Error: Give valid context local/remote.\n");
                tb_usage();
            }
            setenv("axi_ttype", optarg, 1);
            break;
        case 'h':
            glob.hostname = optarg;
            setenv("axi_host", optarg, 1);
            break;
        case 'o':
            if (!strcasecmp(optarg, "linux")) {
                glob.config_file = "_linux";
                break;
            }
            if (!strcasecmp(optarg, "bsd")) {
                glob.config_file = "_bsd";
                break;
            }
            if (!strcasecmp(optarg, "windows")) {
                glob.config_file = "_windows";
                break;
            }
            fprintf(stderr, "* testbot: Error: Provide a valid platform!\n");
            tb_usage();
        case 'p':
            glob.port = atoi(optarg);   // fixme
            setenv("axi_port", optarg, 1);
            break;
        case 'd':
            glob.test_dir = optarg;
            break;
        case 'r':
            if (!strcasecmp(optarg, "y")) {
                glob.refresh = OPT_YES;
                break;
            }
            if (!strcasecmp(optarg, "n")) {
                glob.refresh = OPT_NO;
                break;
            }
            if (!strcasecmp(optarg, "a")) {
                glob.refresh = OPT_ASK;
                break;
            }
            fprintf(stderr, "* testbot: Error: invalid parameter '%s'\n\n",
                    optarg);
            tb_usage();
        case 'v':
            glob.verbose = TRUE;
            break;
        case 'D':
            glob.act_as_daemon = TRUE ;
        }
    }
    return TRUE;
}


/********************************************************/
static void tb_usage(void)
{
    printf("TestBot version %s\n", VER);
    printf("testbot -t testType -o remoteOS -h host -p port -d testDir -r refresh\n");
    printf("-D           : act as daemon( axigenhost )\n");
    printf("-d tests_dir : The directory containing the test scripts\n");
    printf("-t test_type : local or remote\n");
    printf("-o remote_OS : The OS that runs on the remote machine\n");
    printf("-h host      : Host on which axigenhost runs.\n");
    printf("-p port      : Port on which axigenhost listens.\n");
    printf("-r refresh   : Restore server's state after each testRun ?: (y)es, (n)o, (a)sk.[default yes]\n");
    printf("-v           : Verbose.\n"); 
    exit(-1);
}

int tb_globalsInit(int argc, char *argv[])
{
    glob.port = 0;
    glob.test_type = 0;         // 0:not set. 1:local 2:remote
    glob.test_dir = NULL;
    glob.hostname = NULL;
    glob.argv = argv;
    glob.argc = argc;
    glob.platf[0] = "linux";
    glob.platf[1] = "bsd";
    glob.platf[2] = "windows";
    glob.config_file = "_linux";
    glob.refresh = OPT_YES;
    glob.verbose = FALSE;
    glob.act_as_daemon = FALSE ;
    getcwd( glob.testbot_path, PATH_MAX ) ;
    if (!getcwd(glob.tmp_dir, PATH_MAX)) {
        printf("cant get current dir:%s\n", strerror(errno));
    }
    return 0 ;
}


int tb_envInit(void)
{
    /* build the PATH like /home/tools/bin:$PATH */
    util_isEnv(AXI_TOOL);
    strcpy(glob.cur_path, getenv(AXI_TOOL));
    strcat(glob.cur_path, ":");
    strcat(glob.cur_path, getenv("PATH"));
    setenv("PATH", glob.cur_path, 1);

    util_isEnv(AXI_PATH);
    util_isEnv(AXI_TTYPE);
    util_isEnv(AXI_START);
    util_isEnv(AXI_TOOL);
    util_isEnv("axi_core_dir");
    util_isEnv("axi_dbg_dir");
    util_isEnv("axi_cfg_file");
    glob.axi_workDir = getenv(AXI_PATH);
    glob.axi_cfgFile = getenv("axi_cfg_file");
    glob.axi_coreDir = getenv("axi_core_dir" ) ;
    glob.axi_dbgDir  = getenv("axi_dbg_dir");
    setenv("PERLLIB", getenv(AXI_TOOL),1);
    tb_setErrorlog();
    return 0 ;
}

static int tb_checkTools(const char* tools_path)
{
    char buf[PATH_MAX]={0} ;
    #define NB_TOOLS 5
    char* tools[NB_TOOLS] ={"axigen_action", "cp", "mkdir", "refresh_client", "rm"}; 
    struct stat s;
    int i, rc ;

    for(i=0; i< NB_TOOLS; ++i) {
        sprintf(buf,"%s/%s", tools_path, tools[i]);
        rc = stat( buf, &s );
        if( rc == -1){
            fprintf(stderr, "Can't find '%s/%s' : %s\n", tools_path, tools[i], strerror(errno));
            exit(-2);
        }
    }
    return 0;
}

/****************************************************************/

static int tb_runBat(const char *bat_name)
{
    int cod;
    char f[PATH_MAX]="./";
    printf("\n\n");
    printf("*-------------------------.\n");
    printf("* testbot: Running script : %s/%s\n", glob.tmp_dir,bat_name);
    printf("*-------------------------'\n");

    strcat(f, bat_name);
    cod = system(f);
    cod >>= 8;
    if( cod == 69 )
        printf("* testbot: PASS\n");
    else
        printf("* testbot: FAIL\n");
    tb_logPrint(cod, bat_name);
    return 0;
}


static int tb_fileAction(const char *fileName, struct stat *statbuf,
                         void *junk)
{
    if (!util_endsWith( fileName, ".bat"))
        return TRUE ;
    tb_axiRefresh(fileName);
//    tb_axiStart();
    getcwd(glob.cur_dir, PATH_MAX);
    tb_setupTmp( fileName);
    chdir(glob.tmp_dir);
    tb_runBat(basename((char*)fileName));
    tb_checkCore(glob.axi_coreDir, glob.axi_dbgDir, glob.axi_workDir,
                 glob.axi_cfgFile, glob.dest_coreDir ) ;
    tb_cleanupTmp() ;
    sleep(2);
    chdir(glob.cur_dir);

    return (TRUE);
}


static int tb_dirAction(const char *fileName, struct stat *statbuf, void *junk)
{
    return (TRUE);
}


int tb_runRecursive(const char *srcName)
{
    recursiveFlag = 1;
    forceFlag = TRUE;
    if (recursiveAction(srcName, recursiveFlag, FALSE,
                        TRUE, tb_fileAction, tb_dirAction, NULL) == FALSE)
    {
        exit(FALSE);
    }
    return TRUE;
}


static int tb_runTests(const char* dir)
{
    struct stat inf;
    int rc=0;
    char fullPath[PATH_MAX] = {0};

    if (stat(dir, &inf) < 0) {
        printf("* testbot: Error: The directory '%s' doesn't exist.\n",
               dir);
        return 0 ;
    }
    getcwd(glob.cur_dir, PATH_MAX);
    rc = chdir(dir);
    if(rc) {
        fprintf(stderr, "! testbot: Can't change to '%s' : %s\n",dir, strerror(errno));
        exit(-2);
    } 
    //! @todo tb sa verific daca tests este local sau global path
    sprintf(fullPath, "%s/%s", glob.cur_dir, dir );
    tb_runRecursive(fullPath);
    return TRUE ;
}


/********************************************************************/



/** Copies source in /tmp/pid, to create a sandbox for the test
    \param source_file[in] An absolute path pointing to a bat file.
                           The existence of a directory with the same name is assumed.
 */

static int tb_setupTmp(const char *source_bat)
{
    char comm[PATH_MAX]={0};
    char cpstr[PATH_MAX]={0};
    int cod;
    char* p;

    sprintf(glob.tmp_dir, "/tmp/%d", getpid());
    cod = mkdir(glob.tmp_dir, 0755);
    if (cod)
    {
        fprintf(stderr, "! testbot: Error: Cannot make directory %s: %s\n",
                glob.tmp_dir, strerror(errno));
        exit(-1);
    }

    if (glob.verbose == TRUE)
        printf("# testbot: Copying %s to '%s'\n", source_bat, glob.tmp_dir);
    sprintf(comm, "/bin/cp -R %s %s/", source_bat, glob.tmp_dir);
    system(comm);               // TODO: replace this with a function

    //Find the dir coresponding to this bat
    strcpy(cpstr, source_bat ) ;
    p = strrchr(cpstr, '.' ) ;
    *p='\0';
    sprintf(comm, "/bin/cp -R %s %s/", cpstr, glob.tmp_dir);
    if (glob.verbose == TRUE)
        printf("* testbot: Running '%s'\n", comm);
    system(comm);               // TODO: replace this with a functionaxi_fresh

    return 0 ;
}



static int tb_cleanupTmp(void)
{
    printf("# testbot: Removing '%s'\n", glob.tmp_dir);
    my_rm(glob.tmp_dir);
    chdir(glob.cur_dir);        // cine e cur_dir
    return 0 ;
}



/** Search a file for axi_fi=y or axi_fi=n . */
static int tb_parseBat(const char *filename)
{
    char line[MAX_LIN]={0};
    char* str=0;
    pcre *re = NULL;
    int erroffset;
    int ovector[30];
    int matches;
    const char *error = NULL;
    struct stat inf;
    re = pcre_compile("#.*axi_fi\\s*=\\s*\"?([y|Y|n|N])\"?\\s+",
                        0,
                        &error,
                        &erroffset,
                        NULL);
    if(!re) {
        fprintf(stderr, "Can't compile regular expression\n");
        exit(-2);
    }
    stat( filename, &inf);
    if ((inf.st_mode & S_IFMT) == S_IFDIR)
    { printf("! testbot: %s filename is a directory\n", filename);
        exit(-2);
    }

    FILE *f = fopen(filename, "r");
    if(!f) {
        fprintf(stderr, "%d Can't open file '%s' : %s\n", __LINE__, filename, strerror(errno) ) ;
        exit(-2);
    }
    printf("# testbot: Scanning %s\n", filename );
    while((str = fgets(line, MAX_LIN-1, f))){
         ;
        matches = pcre_exec(re, NULL, str, strlen(str), 0, 0, ovector, 30);
        if (matches >= 2) {
            if (tolower(str[ovector[2]]) == 'y') {
                fclose(f);
                return OPT_YES;
            }
            if (tolower(str[ovector[2]]) == 'n') {
                fclose(f);
                return OPT_NO;
            }
        }
    }
    fclose(f);
    return OPT_YES;             /* If nothing is found, return the default
                                   which is OPT_YES. */
}



int tb_checkCore(const char* core_srcDir, const char* dbg_srcDir, const char* axi_workDir,
                 const char* axi_cfgFile, const char* crash_destDir )
{
    if(glob.test_type == TEST_LOCAL )
        return util_checkCoreLocal(core_srcDir, dbg_srcDir, axi_workDir, axi_cfgFile, core_srcDir) ;
    if(glob.test_type == TEST_REMOTE)
        return tb_checkCoreRemote(core_srcDir, dbg_srcDir, axi_workDir, axi_cfgFile, core_srcDir) ;
    return FALSE ;
}


static int tb_checkCoreRemote(const char* core_srcDir, const char* dbg_srcDir, const char* axi_workDir,
                              const char* axi_cfgFile, const char* crash_destDir )
{
    char cmd[MAX_LIN]={0}; // Max line should therefore be 3 times the length of PATH_MAX
    int rc = 0 ;
    int sock ;

    sock = sock_connectTo( glob.hostname, glob.port );
    sprintf(cmd, "CHECKCORE %s %s %s %s %s\r\n",
            core_srcDir, dbg_srcDir, axi_workDir, axi_cfgFile, crash_destDir );
    sock_sendLine(sock, cmd ) ;
    rc = sock_getStatus( sock );
    close(sock);
    if( rc ) {
        printf("---CORE---(do the wall stuff)\n");
        return TRUE ;
    }
    return FALSE ;
}



/** Restore the default Axigen state. */
int tb_axiRefresh(const char *bat_file)
{
    int cod;
     int rc=0;

    if (glob.refresh == OPT_NO)
        return 0 ;

    if (glob.refresh == OPT_ASK)
    {
        char r = 0;

        do{
            printf("* testbot: Reinstall default axigen configuration?[y/n]:");
            r = getchar();
        }while (r != 'y' && r != 'n') ;
        if (r == 'n') {
            printf("# testbot: Keeping axigen's current state\n");
            return 0 ;
        }
    }

    cod = tb_parseBat(bat_file);
    if (cod == OPT_NO)
        return 0 ;

    /* We excluded all NO's, so we're left with the yes. */
    /* Try to restore the default axigen state --groleo */
    rc = system("refresh_client");
    printf("%d\n", rc );
    if(rc == -1 || WEXITSTATUS(rc)!=0)
    {
        printf("! testbot: Error: Could not make refresh!\n");
        exit(1);
    }

    return 0 ;
}





static int tb_logPrint( const int cod,  const char *name)
{
    char *nm;
    FILE *f;
#if 0
    util_isEnv("axi_errorlog");
    nm = getenv("axi_errorlog");
    if (cod == 69)
    {
        printf("* testbot: Script exited ok\n");
        return 0 ;
    }
    f = fopen(nm, "a");
    if (!f)
    {
        fprintf(stderr, "* testbot: Error: Can't open %s\n", nm);
        exit(-1);
    }
    fprintf(f, "* testbot: Script %s has exited with code %d\n", name, cod);     // FIXME:change 
                                                                                // 
    // this
    fclose(f);
#endif
    return 0 ;
}






int tb_isNumber(char *nr)
{
    int i;

    for (i = 0; i < strlen(nr); ++i)
    {
        if (!isdigit(nr[i]))
            return 0;
    }
    return 1;
}



static int tb_parseConf()
{
    char buf[MAX_LIN];
    pcre *re = NULL;
    int erroffset;
    int offsetv[30];    //! offset vector, pointing to the found matches
    int matches;
    const char *error = NULL, *line=NULL;
    char varName[MAX_LIN];
    char varVal[MAX_LIN];
    int len;
    char result[5000]={0};

    FILE *f = fopen(glob.config_file, "r");

    if(!f) {
        printf("! testbot: Error: Could not find config file: %s: %s!\n",
            glob.config_file, strerror(errno));
        exit(1);
    }
    re = pcre_compile("(\\w+)\\s*=\\s*\"(.+)\"", 0, &error, &erroffset, NULL);


    while ((line = fgets(buf, MAX_LIN, f) )) {
        char *c = strchr(line, '#');
        if (c) continue ;

        //! @todo pcre_dfa_exec might be slightly faster

        matches = pcre_exec(re, NULL, line, strlen(line), 0, 0, offsetv, 30);
        if( matches < 3 ) continue ;

        len = offsetv[3] - offsetv[2];
        memcpy(varName, line + offsetv[2], len);
        varName[len] = '\0';


        len = offsetv[5] - offsetv[4];
        memcpy(varVal, line + offsetv[4], len);
        varVal[len] = '\0';
        //! @todo expand any ${VARIABLE} found in varVal
        expand_env( varVal, varName, sizeof(result) );

    }
    fclose(f);
    return 0;
}

/**
 * \brief search and expand any occurence in str, of ${VARNAME}
 * \brief placing the result in result
 * \todo how should i know the length of the memory allocated in result ?provide another param
 * UGLY HACK ( to be revised in future) */
int
expand_env(char * str, char* varName, int maxLen )
{
    pcre* re = NULL;
    int offsetv[30];
    int matches=0;
    char* tmpVar=NULL;
    char  tmp1[4096]={0};
    char tmp2[4096]={0};
    const char *error = NULL;
      int erroffset;
    re = pcre_compile("\\$\\{(.+)\\}", 0, &error, &erroffset, NULL);
    if(!re) {printf("error\n");return FALSE;}
    matches = pcre_exec(re, NULL, str, strlen(str), 0, 0, offsetv, 30);
    if(matches < 2) {
        setenv(varName, str, 1);
    if (glob.verbose == TRUE)
        printf("export $%s=%s\n", varName, str);

    return FALSE ;}
    memcpy( tmp1, str+offsetv[0]+2, offsetv[1]-offsetv[0]-3 );
    strncpy(tmp2, str, offsetv[0]);
    strcat(tmp2,getenv(tmp1));
    strcat(tmp2, str+offsetv[1]);
    //printf("[%s]--[%s]\n", tmp1, tmp2);
    setenv(varName, tmp2, 1);
    if (glob.verbose == TRUE)
        printf("export $%s=%s\n", varName, tmp2);

    return TRUE ;
}
/*
   Ar trebui sa fie ceva de genul. executabil local/remote [platforma_remote]
   [host_remote] [port_remote] director/fisier de teste

   prin local se inteleg testele care nu au nevoie de ce a fost implementat in 
   proiectul acesta, adik de tool-urile de cp, rm, etc

   Optiune inseamana o litera: y, dupa fiecare test se face fresh install, n - 
   nu se face fresh install, a - ask, se intreaba */

static int tb_setErrorlog()
{
    char rez[MAX_LIN] = "", pathname[PATH_MAX] = "";
    char *host;
    char *defhost = "localhost";

    host = getenv("axi_host");
    if (!host)
        host = defhost;

    if (getcwd(pathname, PATH_MAX) == NULL)
    {
        printf("! testbot: Error: getting current dirrectory\n");
        return 1;
    }

    sprintf(rez, "%s/errors/error.log.%s-%d", pathname, host, getpid());
    printf("# testbot: log is: %s\n", rez);
    return setenv("axi_errorlog", rez, 1);
}








